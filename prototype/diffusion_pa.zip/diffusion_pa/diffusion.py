from diffusers import StableDiffusionPipeline

model = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5")

