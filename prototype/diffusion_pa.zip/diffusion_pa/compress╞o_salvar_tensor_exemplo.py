import numpy as np
import lzma

# Exemplo de tensor NumPy
tensor = np.random.randn(2, 320, 64, 64).astype(np.float16)

# Salvar e comprimir com LZMA
with lzma.open('meu_tensor_comprimido_lzma.npy.xz', 'wb') as f:
    np.save(f, tensor)

# Carregar o tensor comprimido com LZMA
with lzma.open('meu_tensor_comprimido_lzma.npy.xz', 'rb') as f:
    tensor_carregado = np.load(f)
